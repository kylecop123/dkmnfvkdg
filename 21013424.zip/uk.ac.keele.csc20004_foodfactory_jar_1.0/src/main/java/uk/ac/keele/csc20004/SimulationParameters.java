/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004;

import java.util.Random;

/**
 * This is just a helper class to keep all the simulation parameters
 * in one place.
 */
public class SimulationParameters {
    private static final Random r = new Random();

    // the calories of the Vegetables ingredient (influences cost and production time)
    public static final double VEGS_CALORIES = 100.0;

    // the calories of the Bun ingredient (influences cost and production time)
    public static final double BUN_CALORIES = 200.0;

    // the calories of the Eggs ingredient (influences cost and production time)
    public static final double EGGS_CALORIES = 300.0;

    // the calories of the Sausage ingredient (influences cost and production time)
    public static final double SAUSAGE_CALORIES = 500.0;

    // how many items (of any product) need to go in a box
    public static final int BOX_SIZE = 5;

    // the number of cooks working in the food company
    public static final int NUM_COOKS = 3;

    // the maximum size of the delivery queues
    public static final int MAX_QUEUE_SIZE = 20;

    // probability to generate "low-cal" food
    public static final float PROB_LOW_CAL = 0.3f;

    // probability to select supermarket delivery
    public static final float PROB_SUPERMARKET = 0.25f;

    /**
     * Helper method to generate a boolean with a given probabilty.
     * 
     * @param p the probability of getting true (a float: needs to be between 0.0 and 1.0)
     * @return a boolean generated with probability p
     */
    public static boolean getRandomBoolean(float p) {
        return r.nextFloat() < p;
    }

}
