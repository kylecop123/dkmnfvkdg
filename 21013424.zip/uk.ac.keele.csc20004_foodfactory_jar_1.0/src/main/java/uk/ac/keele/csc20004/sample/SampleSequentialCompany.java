/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.SimulationParameters;
import uk.ac.keele.csc20004.food.AbstractFoodCompany;
import uk.ac.keele.csc20004.food.BreakfastRollCook;
import uk.ac.keele.csc20004.food.Cook;
import uk.ac.keele.csc20004.food.DeliveryArea;
import uk.ac.keele.csc20004.food.FoodBox;
import uk.ac.keele.csc20004.food.FoodCompany;
import uk.ac.keele.csc20004.food.VeggieRollCook;

/**
 * An example of a simualted company, in a sequential setting.
 */
public class SampleSequentialCompany extends AbstractFoodCompany {
    DeliveryArea deliveries = new SampleDeliveryArea();

    /**
     * Constructor for the company.
     * 
     * @param boxSize the number of computers necessary to fill a box
     */
    public SampleSequentialCompany(int boxSize) {
        super(boxSize);
    }

    @Override
    public void enqueueForSupermarketDelivery(FoodBox b) throws InterruptedException {
        deliveries.pushToSupermarketQueue(b);
    }

    @Override
    public void enqueueForBakeryDelivery(FoodBox b) throws InterruptedException {
        deliveries.pushToBakeryQueue(b);
    }

    @Override
    public FoodBox sell() throws InterruptedException {
        return deliveries.poll();
    }

    /**
     * The method to implement a demo of the operations of the company in a
     * sequential setting.
     * Note that this implementation *does not* necessarily meet the requirements
     * for the coursework.
     * The purpose of this code is only to show how the classes in the provided
     * starting code may fit together
     * 
     * @param args to provide args from the command line (not used)
     */
    public static void main(String[] args) {
        int boxSize = SimulationParameters.BOX_SIZE;
        int numCooks = SimulationParameters.NUM_COOKS;

        FoodCompany company = new SampleSequentialCompany(boxSize);

        // Create a few cooks for the company. I'll create NUM_COOKS cooks
        // per each type of food we can produce; in this case:
        // - Breakfast roll
        // - Veggie roll
        // - SampleFoodProduct
        Cook cooks[] = new Cook[numCooks * 3];

        for (int i = 0; i < numCooks; i++) {
            boolean supermarket;

            supermarket = SimulationParameters.getRandomBoolean(SimulationParameters.PROB_SUPERMARKET);
            cooks[i] = new BreakfastRollCook(company, boxSize, supermarket);

            supermarket = SimulationParameters.getRandomBoolean(SimulationParameters.PROB_SUPERMARKET);
            cooks[i + numCooks] = new VeggieRollCook(company, boxSize, supermarket);

            supermarket = SimulationParameters.getRandomBoolean(SimulationParameters.PROB_SUPERMARKET);
            cooks[i + 2 * numCooks] = new SampleSequentialCook(company, boxSize, supermarket);
        }

        try {
            int numBoxes = 2;

            int count = 0;
            for (int i = 0; i < numBoxes; i++) {
                for (Cook cook : cooks) {
                    FoodBox b = cook.prepareFoodBox();
                    System.out.println(cook.toString()+ " - prepared: " + b);

                    if (b.isSupermarket()) {
                        company.enqueueForSupermarketDelivery(b);
                        System.out.println(cook.toString()+ " - enqueued for supermaket delivery: " + b);
                    } else {
                        company.enqueueForBakeryDelivery(b);
                        System.out.println(cook.toString()+ " - enqueued for bakery delivery: " + b);
                    }
                    count++;
                }

            }

            System.out.println("\nPrepared " + count + " boxes\n\n\n");

            // Now I'll simulate the sale of boxes
            // You could use the SalesManager here:
            // Thread salesManager = new SampleSalesManager(company);
            // salesManager.start();
            // but since the code is sequential, I'll just call the sell() method directly:
            count = 0;
            for (int i = 0; i < numBoxes * numCooks * 3; i++) {
                FoodBox b = company.sell();

                System.out.println("Sold: " + b);
                count++;
            }

            System.out.println("\nSold " + count + " boxes");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
