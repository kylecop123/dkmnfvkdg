/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.products;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.Ingredient;
import uk.ac.keele.csc20004.food.ingredients.Vegetables;

public class VeggieRoll extends AbstractFood {
    public VeggieRoll(Bun bun, Vegetables vegetables) {
        super(new Ingredient[]{bun, vegetables});
    }

    @Override
    public String toString() {
        return "Vroll" + super.toString();
    }
    
}
