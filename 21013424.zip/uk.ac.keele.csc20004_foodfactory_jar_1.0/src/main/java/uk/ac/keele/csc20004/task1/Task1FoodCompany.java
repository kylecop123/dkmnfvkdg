/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.task1;


//importing packages
import uk.ac.keele.csc20004.Cook;
import uk.ac.keele.csc20004.DeliveryQueue;
import uk.ac.keele.csc20004.FastFoodDistribution;
import uk.ac.keele.csc20004.food;
import uk.ac.keele.csc20004.LowCalFood;
import uk.ac.keele.csc20004.PackageQueue;
import uk.ac.keele.csc20004.SalesSupervisor;


//
import uk.ac.keele.csc20004.food.AbstractFoodCompany;
import uk.ac.keele.csc20004.food.FoodBox;

public class Task1FoodCompany extends AbstractFoodCompany {
    PackageQueue deliveries = new PackageQueue();
    //The constructor for the Task1FoodCompany Class
    //

    public Task1FoodCompany(int boxSize) {
        super(boxSize);
        // TODO add your code here as necessary
    }
    //Takes the FoodBox object as a parameter
    //Using the method to add the box to the supermarket delivery queue
    @Override
    public void enqueueForSupermarketDelivery(FoodBox b) throws InterruptedException {
        deliveries.pushSupermarket(b);
    }

    @Override
    public void enqueueForBakeryDelivery(FoodBox b) throws InterruptedException {
        deliveries.pushBakery(b);
    }

    @Override
    public FoodBox sell() throws InterruptedException {
        // TODO add your code here and return the appropriate value
        return null;
    }

    public static void main(String[] args) {
        // TODO add your code here to show how
        // you can simulate the operations of the company in
        // a sequential setting using the classes you implemented

    }

}
