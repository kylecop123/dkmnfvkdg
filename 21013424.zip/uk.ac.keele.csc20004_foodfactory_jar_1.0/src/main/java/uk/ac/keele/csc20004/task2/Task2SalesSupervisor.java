/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task2;

/**
 *
 * @author kylec
 */
import uk.ac.keele.csc20004.food.FoodBox;

import java.util.List;
import java.util.Random;

public class Task2SalesSupervisor {

    private final String name;
    private final List<Task2DeliveryQueue> deliveryQueues;

    public Task2SalesSupervisor(String name, List<DeliveryQueue> deliveryQueues) {
        this.name = name;
        this.deliveryQueues = deliveryQueues;
    }

    public void sellBoxes() {
        Random random = new Random();
        try {
            while (true) {
                // Get a random delivery queue and try to get a box to sell
                Task2DeliveryQueue queue = deliveryQueues.get(random.nextInt(deliveryQueues.size()));
                FoodBox foodBox = queue.getBox();

                // If there is no box in the queue, wait for some time and try again
                if (foodBox == null) {
                    Thread.sleep(random.nextInt(2000) + 1000);
                    continue;
                }

                // Sell the food box and wait for some time before selling the next one
                System.out.println(name + " sold " + foodBox.getName() + " for $" + foodBox.getCost());
                Thread.sleep(random.nextInt(2000) + 1000);
            }
        } catch (InterruptedException e) {
            System.out.println(name + " has finished selling.");
        }
    }
}