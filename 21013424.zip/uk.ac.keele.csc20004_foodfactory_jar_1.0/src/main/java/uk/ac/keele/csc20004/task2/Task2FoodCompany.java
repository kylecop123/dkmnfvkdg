/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.task2;

import uk.ac.keele.csc20004.food.AbstractFoodCompany;
import uk.ac.keele.csc20004.food.FoodBox;
import uk.ac.keele.csc20004.food.LowCalFood;
import uk.ac.keele.csc20004.food.Cook;

/**
 * TASK 2 REPORT
 * Use this javadoc to submit your report.
 * Please address the following points:
 * 
 * 1) What are the potential issues due to concurrent access to the storage and queues? 
 *    How did you handle them?
 * Potential issues with concurrent access to the storage and queues include deadlocks, race conditions and data inconsistency.
 * I used locks such as ReEntrant lock.
 * I also ensured that i avoided using nested locks to avoid potential deadlock situations, ensuring that i did not use a 
 * circular dependency between locks.
 * 
 * 
 * 2) How did you make sure that your solution is not causing deadlock/livelock?
 * Avoiding using nested locks and keeping consistency within predetermined lock orders,
 * aswell as avoiding long held locks as it can increase contention and reduce concurrency
 * 
 * 
 * 3) Discuss whether starvation may occur, and where; and what is your approach 
 *    to deal with it
 * Starvation may occur if a thread with a lower priority is frequently competing for a lock with higher priority, causing it 
 * to wait indefinitely to access a lock, my approach to deal with this is possibly increasing a threads priority the longer they have waited,
 * ensuring that threads are never waiting for a certain amount of time due to aging.
 * 
 * @author 21013424
 */
public class Task2FoodCompany extends AbstractFoodCompany {
    Task2DeliveryQueue deliveries = new Task2DeliveryQueue();
    

    public Task2FoodCompany(int boxSize) {
        super(boxSize);
    }

    @Override
    public void enqueueForSupermarketDelivery(FoodBox b) throws InterruptedException {
        synchronized(deliveries) {
            deliveries.pushSupermarket(b);
        
        }
    } 

    @Override
    public void enqueueForBakeryDelivery(FoodBox b) throws InterruptedException {
        synchronized(deliveries){
            deliveries.pushBakery(b);
        }
    }

    @Override
    public FoodBox sell() throws InterruptedException {
        synchronized(deliveries) {
            return deliveries.poll();
        }
    }

    public static void main(String[] args) {
    }
}