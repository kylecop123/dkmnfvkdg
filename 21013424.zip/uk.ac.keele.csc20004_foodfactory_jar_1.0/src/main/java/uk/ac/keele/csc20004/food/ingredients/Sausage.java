/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

import uk.ac.keele.csc20004.SimulationParameters;

/**
 * A concrete implementation of an ingredient: sausages.
 */
public class Sausage extends Ingredient {
    public static int ID = 0;
    public Sausage() {
        super(ID++);
    }

    @Override
    public double getCalories() {
        return SimulationParameters.SAUSAGE_CALORIES;
    }
    
    @Override
    public String toString() {
        return "s(" + super.toString() + ")";
    }
}
