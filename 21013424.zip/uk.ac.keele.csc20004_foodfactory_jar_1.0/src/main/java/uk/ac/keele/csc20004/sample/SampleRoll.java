/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.Ingredient;
import uk.ac.keele.csc20004.food.products.AbstractFood;

/**
 * A sample class to show how a new type of food product can
 * be defined: in this case, it's completely imaginary as 
 * it is made up of a just a plain bun.
 */
public class SampleRoll extends AbstractFood {
    
    /**
     * Creates a new "sample" food product, made up of a plain bun
     * 
     * @param bun the only ingredient of this type of product
     */
    public SampleRoll(Bun bun) {
        super(new Ingredient[]{bun});
    }

    @Override
    public String toString() {
        return "SR" + super.toString();
    }

}
