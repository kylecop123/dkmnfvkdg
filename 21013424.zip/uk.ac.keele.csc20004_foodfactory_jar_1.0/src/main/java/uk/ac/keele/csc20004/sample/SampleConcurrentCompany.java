/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 First sit    *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.SimulationParameters;
import uk.ac.keele.csc20004.food.AbstractFoodCompany;
import uk.ac.keele.csc20004.food.DeliveryArea;
import uk.ac.keele.csc20004.food.FoodBox;
import uk.ac.keele.csc20004.food.FoodCompany;

/**
 * An example of a simulated company, in a concurrent setting.
 * 
 * This sample code uses the only available concurrent implementation 
 * for a cook (SimpleConcurrentCook); you'll have to provide yoyr own 
 * concurrent implementation for the other classes.
 */
public class SampleConcurrentCompany extends AbstractFoodCompany {
    DeliveryArea deliveries = new SampleDeliveryArea();

    public SampleConcurrentCompany(int boxSize) {
        super(boxSize);
    }

    /**
     * Note that this implementation *does not* necessarily meet the requirements
     * for the coursework. You will need to implement appropriate synchronization
     * 
     * @param b the box to be addedd to supermarket delivery
     */
    @Override
    public void enqueueForSupermarketDelivery(FoodBox b) throws InterruptedException {
        synchronized (deliveries) {
            deliveries.pushToSupermarketQueue(b);
        }
    }

    /**
     * Note that this implementation *does not* necessarily meet the requirements
     * for the coursework. You will need to implement appropriate synchronization
     * 
     * @param b the box to be addedd to bakery delivery
     */
    @Override
    public void enqueueForBakeryDelivery(FoodBox b) throws InterruptedException {
        synchronized (deliveries) {
            deliveries.pushToBakeryQueue(b);
        }
    }

    @Override
    public FoodBox sell() throws InterruptedException {
        synchronized (deliveries) {
            return deliveries.poll();
        }
    }

    /**
     * The method to implement a demo of the operations of the company in a
     * concurrent setting.
     * Note that this implementation *does not* necessarily meet the requirements
     * for the coursework.
     * The purpose of this code is only to show how the classes in the provided
     * starting code may fit together
     * 
     * @param args to provide args from the command line (not used)
     */
    public static void main(String[] args) {
        int boxSize = SimulationParameters.BOX_SIZE;
        int numCooks = SimulationParameters.NUM_COOKS;

        FoodCompany company = new SampleConcurrentCompany(boxSize);

        Thread bakeryCooks[] = new Thread[numCooks];
        for (int i = 0; i < numCooks; i++) {
            bakeryCooks[i] = new Thread(new SampleConcurrentCook(company, boxSize, false));
        }

        Thread supermarketCooks[] = new Thread[numCooks];
        for (int i = 0; i < numCooks; i++) {
            supermarketCooks[i] = new Thread(new SampleConcurrentCook(company, boxSize, true));
        }

        Thread salesManager = new SampleSalesManager(company);

        for (int i = 0; i < numCooks; i++) {
            bakeryCooks[i].start();
            supermarketCooks[i].start();
        }

        salesManager.start();
    }
}
