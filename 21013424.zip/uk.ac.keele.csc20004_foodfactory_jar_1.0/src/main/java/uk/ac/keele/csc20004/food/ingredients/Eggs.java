/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

import uk.ac.keele.csc20004.SimulationParameters;

/**
 * A concrete implementation of an ingredient: eggs.
 */
public class Eggs extends Ingredient {
    public static int ID = 0;
    public Eggs() {
        super(ID++);
    }

    @Override
    public double getCalories() {
        return SimulationParameters.EGGS_CALORIES;
    }
    
    @Override
    public String toString() {
        return "e(" + super.toString() + ")";
    }
}
