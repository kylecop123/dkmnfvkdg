/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task1;

import java.util.List;

import java.util.List;

/**
 *
 * @author kylec
 */

  
class SalesSupervisor {
    private final String name;
    private final List<DeliveryQueue> deliveryQueues;

    public SalesSupervisor(String name, List<DeliveryQueue> deliveryQueues) {
        this.name = name;
        this.deliveryQueues = deliveryQueues;
    }

    public void sellBoxes() {
        while (true) {
            // Your logic for selling boxes goes here
            // For example, you can retrieve boxes from delivery queues and process them
            // Remember to add some sleep to avoid busy waiting.
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
