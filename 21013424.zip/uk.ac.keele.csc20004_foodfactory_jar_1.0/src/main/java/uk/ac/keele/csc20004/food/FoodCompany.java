/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.Eggs;
import uk.ac.keele.csc20004.food.ingredients.FoodStorage;
import uk.ac.keele.csc20004.food.ingredients.Sausage;
import uk.ac.keele.csc20004.food.ingredients.Vegetables;

/**
 * Interface defining the functionalities that are expected
 * in our simulation of a company manufaturing computers.
 */
public interface FoodCompany {
    /**
     * @return the shelf holding eggs
     */
    public FoodStorage<Eggs> getEggsStorage();

    /**
     * @return the shelf holding buns
     */
    public FoodStorage<Bun> getBunStorage();

    /**
     * @return the fridge holding sausages
     */
    public FoodStorage<Sausage> getSausageStorage();

    /**
     * @return the fridge holding vegetables
     */
    public FoodStorage<Vegetables> getVegetablesStorage();

    /**
     * Adds a box to the supermarket delivery queue,
     * ready to be sold.
     * 
     * @param b the box to be sold to supermarkets
     * @throws InterruptedException due to our simulation via sleep()
     */
    public void enqueueForSupermarketDelivery(FoodBox b) throws InterruptedException;

    /**
     * Adds a box to the supermarket delivery queue,
     * ready to be sold.
     * 
     * @param b the box to be sold to supermarkets
     * @throws InterruptedException due to our simulation via sleep()
     */
    public void enqueueForBakeryDelivery(FoodBox b) throws InterruptedException;

    /**
     * Simulates the sale of a food box, by retrieving an element
     * from the deliery queues. The requirement is that the
     * bakery delivery queue is checked first, then the supermarket one.
     * 
     * @throws InterruptedException due to our simulation via sleep()
     */
    public FoodBox sell() throws InterruptedException;
}
