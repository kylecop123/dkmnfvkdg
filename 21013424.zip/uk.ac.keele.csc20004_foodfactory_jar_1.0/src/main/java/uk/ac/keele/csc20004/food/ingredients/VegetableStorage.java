/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

/**
 * A concrete implementation of a food storage (for vegetables).
 */
public class VegetableStorage extends FoodStorage<Vegetables> {

    @Override
    protected Vegetables createIngredient() {
        return new Vegetables();
    }
}
