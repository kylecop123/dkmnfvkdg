/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.Eggs;
import uk.ac.keele.csc20004.food.ingredients.FoodStorage;
import uk.ac.keele.csc20004.food.ingredients.Sausage;
import uk.ac.keele.csc20004.food.products.BreakfastRoll;
import uk.ac.keele.csc20004.food.products.Food;

/**
 * A class defining the functionality of a cook, in this case specialised in 
 * preparing breakfast rolls. Basically their only job is to prepare
 * this specific type of food once they get the necessary ingredients.
 */
public class BreakfastRollCook extends AbstractCook {
    /**
     * Creates a new cook, specialised to produce breakfast rolls.
     * Note that this implementation is not thread safe, as it does not implement
     * any protection from concurrent access to the storage areas.
     * 
     * @param company a reference to the company where the cook works
     * @param boxSize the number of products necessary to fill a box
     * @param supermarket true if the cook is specialised in preparing rolls for supermarkets
     */
    public BreakfastRollCook(FoodCompany company, int boxSize, boolean supermarket) {
        super(company, boxSize, supermarket);
    }

    /**
     * The method that creates a new BreakfasRoll from its ingredients. 
     * It will acceess the storage areas to get the ingredients, in the 
     * order specific for the recipe, then simulate the preapration of the product.
     * 
     * @return a new Food product, created from ingredients
     * @throws InterruptedException due to our simulation via sleep()
     */
    @Override
    public Food prepareFood() throws InterruptedException {
        FoodStorage<Eggs> eggsShelf = company.getEggsStorage();
        FoodStorage<Bun> bunShelf = company.getBunStorage();
        FoodStorage<Sausage> sausageFridge = company.getSausageStorage();

        // first, get eggs from the storage
        Eggs eggs = eggsShelf.retrieveIngredient();
        // then, get a bun from the storage
        Bun bun = bunShelf.retrieveIngredient();
        // finally, get a sausage from the storage
        Sausage sausage = sausageFridge.retrieveIngredient();

        //now prepare roll
        Food roll = new BreakfastRoll(eggs, bun, sausage);

        return roll;

    }

    @Override
    public String toString() {
        return "BreakfastRoll"+super.toString();
    }
}
