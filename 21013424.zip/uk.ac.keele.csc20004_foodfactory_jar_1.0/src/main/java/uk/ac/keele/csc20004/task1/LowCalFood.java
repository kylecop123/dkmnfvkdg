/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task1;

/**
 *
 * @author kylec
 */
class LowCalFood extends Food {
    public LowCalFood(Food food) {
        super(food.getName(), (int) (food.getCalories() * 0.9));
    }
}
