/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task2;

/**
 *
 * @author kylec
 */
import uk.ac.keele.csc20004.food.Food;
import uk.ac.keele.csc20004.food.FoodBox;

public class Task2LowCalFood extends FoodBox {

    private final FoodBox foodBox; // Reference to the original food item

    public Task2LowCalFood(FoodBox foodBox) {
        super("LowCal " + foodBox.getName(), (int) (foodBox.getCalories() * 0.9)); // Set the name and calories for the LowCalFood
        this.foodBox = foodBox;
    }

    // Implement the recipe for the LowCalFood, same as the original food item
    @Override
    public void prepareFood() {
        foodBox.prepareFood();
    }
}