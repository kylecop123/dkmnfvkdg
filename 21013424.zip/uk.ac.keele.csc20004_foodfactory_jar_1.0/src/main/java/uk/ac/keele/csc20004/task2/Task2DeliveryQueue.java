/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task2;

/**
 *
 * @author kylec
 */
import uk.ac.keele.csc20004.food.FoodBox;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Task2DeliveryQueue {
    private final int maxQueueSize;
    private final List<FoodBox> queue = new ArrayList<>();
    private final Lock lock = new ReentrantLock();

    public Task2DeliveryQueue(int maxQueueSize) {
        this.maxQueueSize = maxQueueSize;
    }

    Task2DeliveryQueue() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void addBox(FoodBox box) {
        lock.lock();
        try {
            queue.add(box);
            queue.sort(Comparator.comparingInt(FoodBox::getCost).reversed());
            if (queue.size() > maxQueueSize) {
                queue.remove(queue.size() - 1);
            }
        } finally {
            lock.unlock();
        }
    }

    public FoodBox getBox() {
        lock.lock();
        try {
            if (!queue.isEmpty()) {
                return queue.remove(0);
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int size() {
        return queue.size();
    }

    void pushSupermarket() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void pushBakery(FoodBox b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void pushSupermarket(FoodBox b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    FoodBox poll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}