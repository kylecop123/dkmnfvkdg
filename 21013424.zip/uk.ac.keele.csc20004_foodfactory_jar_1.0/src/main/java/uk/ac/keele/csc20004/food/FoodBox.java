/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import java.util.Arrays;

import uk.ac.keele.csc20004.food.products.Food;

/** 
 * A container of food products. 
 */
public class FoodBox {
    private Food[] products;
    private final boolean supermarket;

    /**
     * Creates a new food box, containing the given products.
     * 
     * @param products the products to be packaged into this box
     * @param supermarket true if this box is for delivery to supermarkets (false for bakeries)
     */
    public FoodBox(Food[] products, boolean supermarket) {
        this.products = new Food[products.length];
        this.products = Arrays.copyOf(products, this.products.length);

        this.supermarket = supermarket;
    }

    public FoodBox(String name, int calories, int BOX_SIZE) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int size() {
        return products.length;
    }

    public double getCost() {
        double cost = 0.0;
        for (Food product : products) {
            cost += product.getCost();
        }
        
        return cost;
    }
    
    /**
     * 
     * @return true if the box is for delivery to supermarkets (false for bakeries)
     */
    public boolean isSupermarket() {
        return supermarket;
    }

    @Override
    public String toString() {
        String prefix = supermarket ? "S-": "B-"; 
        String descr = prefix+"Box[£" + getCost() + "]: ";
        for (Food product : products) {
            descr += product;
            descr += " ";
        }
        return descr;
    }
}
