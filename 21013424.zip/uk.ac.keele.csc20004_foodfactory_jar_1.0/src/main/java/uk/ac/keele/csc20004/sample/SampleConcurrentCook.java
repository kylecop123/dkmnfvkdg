/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.SimulationParameters;
import uk.ac.keele.csc20004.food.AbstractCook;
import uk.ac.keele.csc20004.food.FoodBox;
import uk.ac.keele.csc20004.food.FoodCompany;
import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.FoodStorage;
import uk.ac.keele.csc20004.food.products.Food;

/**
 * A sample cook that prepares rolls concurrently.
 */
public class SampleConcurrentCook extends AbstractCook implements Runnable {
    /**
     * Creates a new sample cook for concurrent preparation of rolls.
     * 
     * @param company a reference to the company where the cook is employed
     * @param boxSize the number of products necessary to fill a box
     * @param supermarket true if the cook is specialised in preparing rolls for supermarkets
     */
    public SampleConcurrentCook(FoodCompany company, int boxSize, boolean supermarket) {
        super(company, boxSize, supermarket);
    }
    
    @Override
    public Food prepareFood() throws InterruptedException {
        FoodStorage<Bun> bunShelf = company.getBunStorage();

        // first, make sure you have exclusive access to the storage, and get a bun
        Bun bun;
        synchronized(bunShelf) {
            bun = bunShelf.retrieveIngredient();

            // if we needed other ingredients, we would need to get them here
            // ...
        }
        //now prepare roll
        Food roll = new SampleRoll(bun);

        boolean lowCal = SimulationParameters.getRandomBoolean(SimulationParameters.PROB_LOW_CAL);
        if (lowCal) {
            // this is where you could "turn" the roll into a low-cal roll
        }

        return roll;
    }

    @Override
    public void run() {
        try {
            while (true) {
                FoodBox b = prepareFoodBox();
                Thread.sleep(100);

                if (b.isSupermarket()) {
                    company.enqueueForSupermarketDelivery(b);
                    System.out.println(this.toString()+ " - enqueued for supermaket delivery: " + b);
                } else {
                    company.enqueueForBakeryDelivery(b);
                    System.out.println(this.toString()+ " - enqueued for bakery delivery: " + b);
                }
        }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "SampleConcurrent"+super.toString();
    }
}
