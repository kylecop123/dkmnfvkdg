/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.sample;

import java.util.ArrayDeque;

import uk.ac.keele.csc20004.food.DeliveryArea;
import uk.ac.keele.csc20004.food.FoodBox;

/**
 * A sample implementation of a delivery area.
 * Note that this implementation *does not* fully meet the
 * requirements for the coursework.
 * In particular: 
 * - there is no check on maximum size constraints
 * - the priority of the queues is not enforced
 * - the queues are not thread-safe
 * 
 * You'll need to address these issues in your own implementation.
 */
public class SampleDeliveryArea implements DeliveryArea {

    // the queue for delivery of boxes to supermarkets
    // note that this data structure *does not* meet the coursework requirements
    // you'll have to make your own choice when addressing the tasks
    private ArrayDeque<FoodBox> supermarketDelivery = new ArrayDeque<>();

    // the queue for delivery of boxes to bakeries
    // note that this data structure *does not* meet the coursework requirements
    // you'll have to make your own choice when addressing the tasks
    private ArrayDeque<FoodBox> bakeryDelivery = new ArrayDeque<>();

    public SampleDeliveryArea() {
    }

    @Override
    public void pushToSupermarketQueue(FoodBox box) {
        supermarketDelivery.push(box);
    }

    @Override
    public void pushToBakeryQueue(FoodBox box) {
        bakeryDelivery.push(box);
    }

    @Override
    public FoodBox poll() {
        if (bakeryDelivery.isEmpty()) {
            return supermarketDelivery.poll();
        } else {
            return bakeryDelivery.poll();
        }
    }

}