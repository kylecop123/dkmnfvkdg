/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

import uk.ac.keele.csc20004.SimulationParameters;

/**
 * A concrete implementation of an ingredient: vegetables.
 */
public class Vegetables extends Ingredient {
    public static int ID = 0;
    public Vegetables() {
        super(ID++);
    }

    @Override
    public double getCalories() {
        return SimulationParameters.VEGS_CALORIES;
    }
    
    @Override
    public String toString() {
        return "v(" + super.toString() + ")";
    }
}
