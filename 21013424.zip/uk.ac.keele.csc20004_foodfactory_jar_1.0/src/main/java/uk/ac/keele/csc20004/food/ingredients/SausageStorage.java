/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

/**
 * A concrete implementation of a food storage (for sausages).
 */
public class SausageStorage extends FoodStorage<Sausage> {

    @Override
    protected Sausage createIngredient() {
        return new Sausage();
    }
}
