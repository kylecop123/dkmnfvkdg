/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task1;

/**
 *
 * @author kylec
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import uk.ac.keele.csc20004.food.FoodBox;

class DeliveryQueue {
    private final int maxQueueSize;
    private final List<FoodBox> queue;
    private final Lock lock = new ReentrantLock();

    public DeliveryQueue(int maxQueueSize) {
        this.queue = new ArrayList<>();
        this.maxQueueSize = maxQueueSize;
    }

    public void addBox(FoodBox box) {
        lock.lock();
        try {
            queue.add(box);
            queue.sort(Comparator.comparingInt(FoodBox::getCost).reversed());
            if (queue.size() > maxQueueSize) {
                queue.remove(queue.size() - 1);
            }
        } finally {
            lock.unlock();
        }
    }

    public FoodBox getBox() {
        lock.lock();
        try {
            if (!queue.isEmpty()) {
                return queue.remove(0);
            }
            return null;
        } finally {
            lock.unlock();
        }
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int size() {
        return queue.size();
    }
}
