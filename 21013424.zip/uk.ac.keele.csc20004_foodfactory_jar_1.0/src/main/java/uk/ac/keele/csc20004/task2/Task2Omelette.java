/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task2;

/**
 *
 * @author kylec
 */
import uk.ac.keele.csc20004.food.FoodBox;

public class Task2Omelette extends FoodBox {

    public Omelette() {
        super("Omelette", 200); // Set the name and calories for the Omelette
    }

    // Implement the recipe for the Omelette
    @Override
    public void prepareFood() {
        System.out.println("Preparing Omelette...");
    }
}