/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.products;

/**
 * Interface defining the basic characteristics of a food product for 
 * our (simulated) food company. Just as for the ingredients, 
 * a food product is characterised by having a calories footprint, a cost and a 
 * processing time.
 */
public interface Food {    

    /**
     * Returns the calories contained in this food product.
     * Those will typically result from the sum of the calories 
     * of its ingredients. 
     * 
     * @return the calories of this product
     */
    public double getCalories();

    /**
     * Returns the cost (in "money units") of this food product.
     * The cost will typically result from the sum of the costs 
     * of its ingredients. 
     * 
     * @return the cost of this product
     */
    public double getCost();

    /**
     * This method can be used when simulating the cook preparing food
     *  by putting a thread to sleep.
     * 
     * @return the time (in ms) it takes to process this food product
     */
    public long getProcessingTime();
}
