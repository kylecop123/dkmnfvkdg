/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import uk.ac.keele.csc20004.food.products.Food;

/**
 * Interface defining the functionality of a cook. B
 * asically their only job is to prepare a specific type of food once
 * they get the necessary ingredients.
 */
public interface Cook {

    /**
     * The method that creates a new food product from the ingredients collected
     * from the storage.
     * 
     * @return a new Food object, created from ingredients
     * @throws InterruptedException due to our simulation via sleep()
     */
    public Food prepareFood() throws InterruptedException;

    /**
     * This method repeatedly calls prepareFood() to fill a box
     * with food items of the same type.
     * 
     * @return a new FoodBox of items of the same type
     * @throws InterruptedException due to our simulation via sleep()
     */
    public FoodBox prepareFoodBox() throws InterruptedException;
}
