/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task2;

/**
 *
 * @author kylec
 */
import uk.ac.keele.csc20004.food.Food;
import uk.ac.keele.csc20004.food.FoodBox;

import java.util.List;
import java.util.Random;

public class Task2Cook implements Runnable {

    private final String name;
    private final List<Food> ingredients;
    private final Task2DeliveryQueue deliveryQueue;

    public Task2Cook(String name, List<Food> ingredients, Task2DeliveryQueue deliveryQueue) {
        this.name = name;
        this.ingredients = ingredients;
        this.deliveryQueue = deliveryQueue;
    }

    @Override
    public void run() {
        Random random = new Random();
        try {
            while (true) {
                // Prepare a food item
                FoodBox foodBox = prepareFoodBox();

                // Add the prepared food box to the delivery queue
                deliveryQueue.addBox(foodBox);

                // Wait for some time before preparing the next food item
                Thread.sleep(random.nextInt(3000) + 1000);
            }
        } catch (InterruptedException e) {
            System.out.println(name + " has finished cooking.");
        }
    }

    private FoodBox prepareFoodBox() {
        // TODO: Implement the logic to prepare a food item based on the ingredients
        // You can randomly choose a recipe from available ingredients
        // For example, to create a VeggieRoll, you will need to get a Bun and Vegetables from the shelves
        // Use the FoodBox class to create a new food item
        return null;
    }
}