/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.SimulationParameters;
import uk.ac.keele.csc20004.food.AbstractCook;
import uk.ac.keele.csc20004.food.FoodCompany;
import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.FoodStorage;
import uk.ac.keele.csc20004.food.products.Food;

/**
 * A sample cook that prepares rolls sequentially.
 */
public class SampleSequentialCook extends AbstractCook {
    /**
     * Creates a new sample cook 
     * 
     * @param company a reference to the company where the cook is employed
     * @param boxSize the number of products necessary to fill a box
     * @param supermarket true if the cook is specialised in preparing rolls for supermarkets
     */
    public SampleSequentialCook(FoodCompany company, int boxSize, boolean supermarket) {
        super(company, boxSize, supermarket);
    }

    @Override
    public Food prepareFood() throws InterruptedException {
        FoodStorage<Bun> bunShelf = company.getBunStorage();

        // first, get a bun from the storage
        Bun bun = bunShelf.retrieveIngredient();
 
        //now prepare roll
        Food roll = new SampleRoll(bun);

        boolean lowCal = SimulationParameters.getRandomBoolean(SimulationParameters.PROB_LOW_CAL);
        if (lowCal) {
            // this is where you could "turn" the roll into a low-cal roll
        }

        return roll;
    }

    @Override
    public String toString() {
        return "SampleSequential"+super.toString();
    }
    
}
