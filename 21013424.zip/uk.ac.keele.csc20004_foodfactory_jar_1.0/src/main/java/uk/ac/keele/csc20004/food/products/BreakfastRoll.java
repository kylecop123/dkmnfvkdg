/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.products;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.Eggs;
import uk.ac.keele.csc20004.food.ingredients.Ingredient;
import uk.ac.keele.csc20004.food.ingredients.Sausage;

public class BreakfastRoll extends AbstractFood {
    public BreakfastRoll(Eggs eggs, Bun bun, Sausage sausage) {
        super(new Ingredient[]{eggs, bun, sausage});
    }

    @Override
    public String toString() {
        return "Broll" + super.toString();
    }
    
}
