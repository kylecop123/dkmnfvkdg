/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

/**
 * A generic class to represent the place where ingredients of a specific
 * type can be stored, and retrieved by cooks.
 * The generic type T can be any of Eggs, Sausage, Bun or Vegetables.
 * The class simulates the time it takes to retrieve an ingredient by putting 
 * the calling thread to sleep.
 */
public abstract class FoodStorage<T extends Ingredient> {
    private void simulateRetrievalTime(T ingredient) throws InterruptedException {
        Thread.sleep(ingredient.getIngredientTime());

    }

    /**
     * This method will need to be implemented in concrete classes to 
     * create an ingredient to be returned when the storage is accessed
     * 
     * @return the ingredient to be returned
     */
    protected abstract T createIngredient();
    
    /**
     * This method represents the access to a food storage:
     * a new ingredient of the specifc type will be created;
     * this method forces the caller to wait for a type dependent 
     * on the specific ingredient.
     * 
     * @return the retieved ingredient
     * @throws InterruptedException due to the presence of the sleep() method
     */
    public final T retrieveIngredient() throws InterruptedException {
        T ingredient = this.createIngredient();

        this.simulateRetrievalTime(ingredient);

        return ingredient;
    }

}