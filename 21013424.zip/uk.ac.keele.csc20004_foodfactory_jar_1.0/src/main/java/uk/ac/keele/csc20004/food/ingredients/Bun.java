/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

import uk.ac.keele.csc20004.SimulationParameters;

/**
 * A concrete implementation of an ingredient: a bun.
 */
public class Bun extends Ingredient {
    public static int ID = 0;
    public Bun() {
        super(ID++);
    }

    @Override
    public double getCalories() {
        return SimulationParameters.BUN_CALORIES;
    }
    
    @Override
    public String toString() {
        return "b(" + super.toString() + ")";
    }
}
