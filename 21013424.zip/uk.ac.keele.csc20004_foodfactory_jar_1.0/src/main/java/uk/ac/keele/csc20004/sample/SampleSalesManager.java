/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 First sit    *
 * **********************/
package uk.ac.keele.csc20004.sample;

import uk.ac.keele.csc20004.food.FoodBox;
import uk.ac.keele.csc20004.food.FoodCompany;

/**
 * An example of a thread simulating the sales manager 
 */
public class SampleSalesManager extends Thread {
    protected final FoodCompany company;

    public SampleSalesManager(FoodCompany company) {
        this.company = company;
    }

    /**
     * Note that this implementation performs busy waiting to check
     * the queues, so it *does not* meet the requirements 
     * for the coursework 
     */
    @Override
    public void run() {
        try {
            while(true) {
                Thread.sleep(500);
                FoodBox box = company.sell();
                if (box != null) {
                    System.out.println("Sold: " + box);
                }
            }    
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
}
