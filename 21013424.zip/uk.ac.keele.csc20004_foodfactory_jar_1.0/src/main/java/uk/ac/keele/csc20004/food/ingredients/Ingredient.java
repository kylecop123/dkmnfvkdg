/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.ingredients;

/**
 * An abstract class defining the basic characteristics of an
 * ingredient for our (simulated) food company: an ingredient will
 * be characterised by a unique id (mostly for printout purposes), 
 * and the amount of calories, which is used to compute the time it takes to 
 * retrieve/pricess the ingredient and its cost (in this implementation, it is 
 * assumed that the time, in ms, is the same as the cost).
 */
public abstract class Ingredient {
    protected int id;

    /**
     * The constructor will only need the serial number. The calories/cost 
     * are not known in this abstract implementation and will need to be 
     * specified in the concrete ones.
     * 
     * @param id the id for this ingredient
     */
    public Ingredient(int id) {
        this.id = id;
    }

    /**
     * Return the serial number of the part
     * 
     * @return the serial number of the part
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the calories contained in this ingredient.
     * The amount of calories is not known in this abstract implementation and
     * will need to be specified in the concrete ones.
     * 
     * @return the calories of this component
     */
    public abstract double getCalories();

     /**
     * This method can be used when simulating the retrieval
     * of an ingredient by putting a thread to sleep.
     * 
     * @return the time (in ms) it takes to retrieve/process this ingredient
     */
    public long getIngredientTime() {
        return Math.round(getCalories());
    }

    @Override
    public String toString() {
        return Integer.toString(id);
    }
}
