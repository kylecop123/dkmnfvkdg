/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import uk.ac.keele.csc20004.food.products.Food;

/** A partial implementation of a cook. 
 * Just adds the implementation of the prepareFoodBox() method.
 */
public abstract class AbstractCook implements Cook {
    private static int ID_COUNTER = 0;

    protected final int id = ID_COUNTER++;

    protected final FoodCompany company;
    protected final int boxSize;
    protected final boolean supermarket;

    /**
     * Creates a new cook, specialised to produce breakfast rolls.
     * Note that this implementation is not thread safe, as it does not implement
     * any protection from concurrent access to the storage areas.
     * 
     * @param company a reference to the company where the cook works
     * @param boxSize the number of products necessary to fill a box
     * @param supermarket true if the cook is specialised in preparing rolls for supermarkets
     */
    public AbstractCook(FoodCompany company, int boxSize, boolean supermarket) {
        this.company = company;
        this.boxSize = boxSize;
        this.supermarket = supermarket;
    }

    @Override
    public FoodBox prepareFoodBox() throws InterruptedException {
        Food[] products = new Food[boxSize];

        for (int i = 0; i < boxSize; i++) {
            products[i] = prepareFood();
        }

        return new FoodBox(products, supermarket);
    }

    @Override
    public String toString() {
        return "Cook-"+id;
    }
    
}
