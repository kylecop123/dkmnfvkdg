/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uk.ac.keele.csc20004.task1;

import java.util.List;
import java.util.Random;
import static uk.ac.keele.csc20004.SimulationParameters.BOX_SIZE;
import uk.ac.keele.csc20004.food.FoodBox;

/**
 *
 * @author kylec
 */
class Cook {
    private final String name;
    private final List<Food> recipe;
    private final DeliveryQueue deliveryQueue;
    private int totalItemsProduced = 0;
    private final Random random = new Random();

    public Cook(String name, List<Food> recipe, DeliveryQueue deliveryQueue) {
        this.name = name;
        this.recipe = recipe;
        this.deliveryQueue = deliveryQueue;
    }

    Cook(String omelette_Cook, List<uk.ac.keele.csc20004.food.Food> of, DeliveryQueue get) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void getIngredients() {
        // Simulate getting ingredients from storage places
        for (Food ingredient : recipe) {
            System.out.println(name + " gets " + ingredient.getName() + " from the storage.");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void cookFood() {
        // Simulate cooking the food
        Food food = recipe.get(recipe.size() - 1);
        System.out.println(name + " starts cooking " + food.getName() + "...");
        try {
            Thread.sleep(food.getCalories());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(name + " has cooked " + BOX_SIZE + " " + food.getName() + " items.");
        totalItemsProduced += BOX_SIZE;
    }

    private boolean isLowCalVersion() {
        return random.nextDouble() < 0.5; // 50% chance of cooking low-calories version
    }

    private Food getFoodType() {
        return isLowCalVersion() ? new LowCalFood(recipe.get(recipe.size() - 1)) : recipe.get(recipe.size() - 1);
    }

    private void packageAndDeliver() {
        // Package the cooked items into a box and deliver to the delivery queue
        Food food = getFoodType();
        System.out.println(name + " is packaging " + BOX_SIZE + " " + food.getName() + " items into a box.");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        deliveryQueue.addBox(new FoodBox(food.getName(), food.getCalories(), BOX_SIZE));
        System.out.println(name + " delivers the box to the delivery queue.");
    }

    public void run() {
        while (totalItemsProduced < BOX_SIZE) {
            getIngredients();
            cookFood();
            packageAndDeliver();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
