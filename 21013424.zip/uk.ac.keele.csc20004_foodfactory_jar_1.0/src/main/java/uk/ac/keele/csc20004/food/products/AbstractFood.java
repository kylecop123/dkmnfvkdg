/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food.products;

import java.util.Arrays;

import uk.ac.keele.csc20004.food.ingredients.Ingredient;

/**
 * This abstract class provides a basic implementation of the
 * methods common to all types of food products. In particular, it
 * defines the cost as the sum of the costs of the ingredients, and 
 * the processing time as equal to the cost.
 * The calories are computed as the sum of the calories of the ingredients.
 * It also defines the method to engrave a serial number for the machine:
 * note that the serial number *must* correspond to the sum of the srial numbers
 * of the components (basically: a way to check the machine was built properly)
 */
public abstract class AbstractFood implements Food {
    protected Ingredient[] ingredients;

    /**
     * Any food product is defined as a collection of ingredients, so
     * the constructor just takes an array of generic Ingredient objects.
     * 
     * @param ingredients an array containing the components
     */
    public AbstractFood(Ingredient[] ingredients) {
        this.ingredients = new Ingredient[ingredients.length];
        this.ingredients = Arrays.copyOf(ingredients, this.ingredients.length);
    }

    @Override
    public double getCalories() {
        double cost = 0;
        for (Ingredient i : ingredients) {
            cost += i.getCalories();
        }

        return cost;
    }

    @Override
    public double getCost() {
        return getCalories();
    }

    @Override
    public long getProcessingTime() {
        return Math.round(getCalories());
    }

    @Override
    public String toString() {
        String descr = "[";

        for (Ingredient i : ingredients) {
            descr += i.toString() + ";";
        }

        descr += "]";
        return descr;
    }
}
