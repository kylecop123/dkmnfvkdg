package uk.ac.keele.csc20004.task1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author kylec
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FastFoodDistribution {

    private static final int NUM_COOKS = 3;
    private static final int MAX_QUEUE_SIZE = 5;
    private static final int BOX_SIZE = 10;

    public static void main(String[] args) {
        Food egg = new Food("Eggs", 100);
        Food sausage = new Food("Sausage", 150);
        Food vegetable = new Food("Vegetables", 50);
        Food bun = new Food("Bun", 200);

        List<DeliveryQueue> deliveryQueues = new ArrayList<>();
        deliveryQueues.add(new DeliveryQueue(MAX_QUEUE_SIZE)); // For Supermarket Delivery
        deliveryQueues.add(new DeliveryQueue(MAX_QUEUE_SIZE)); // For Bakery Delivery

        List<Cook> cooks = new ArrayList<>();
        cooks.add(new Cook("Egg Cook", List.of(egg, bun, sausage), deliveryQueues.get(0)));
        cooks.add(new Cook("Veggie Roll Cook", List.of(bun, vegetable), deliveryQueues.get(0)));
        cooks.add(new Cook("Omelette Cook", List.of(egg, sausage, vegetable), deliveryQueues.get(0)));
        cooks.add(new Cook("Burger Cook", List.of(bun, sausage), deliveryQueues.get(1)));
        cooks.add(new Cook("Fries Cook", List.of(bun), deliveryQueues.get(1)));
        cooks.add(new Cook("Drink Cook", List.of(), deliveryQueues.get(1))); // For drinks, no ingredients needed

        SalesSupervisor salesSupervisor = new SalesSupervisor("Sales Supervisor", deliveryQueues);

         // Start the simulation with threads
        List<Thread> cookThreads = new ArrayList<>();
        for (Cook cook : cooks) {
            cookThreads.add(new Thread(cook::run));
        }

        // Use a lambda expression for the sales thread
        Thread salesThread = new Thread(() -> salesSupervisor.sellBoxes());

        for (Thread thread : cookThreads) {
            thread.start();
        }
        salesThread.start();

        try {
            for (Thread thread : cookThreads) {
                thread.join();
            }
            salesThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
