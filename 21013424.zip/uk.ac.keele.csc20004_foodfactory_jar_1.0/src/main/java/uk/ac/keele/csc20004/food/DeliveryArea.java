/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

/**
 * An interface to define common methods to implement a delivery area,
 * which is a waiting space for Computer boxes before being sold. 
 * It necessarily needs to handle two queues, one for domestic, the 
 * other for internatinonal delivery.
 */
public interface DeliveryArea {
    /**
     * Adds a box to the supermarket delivery queue. 
     * 
     * @param box the box to be sold to supermarkets.
     * @throws InterruptedException due to our simulation via sleep()
     */
    public void pushToSupermarketQueue(FoodBox box) throws InterruptedException;

    /**
     * Adds a box to the international delivery queue. 
     * 
     * @param box the box to be sold to bakeries.
     * @throws InterruptedException due to our simulation via sleep()
     */
    public void pushToBakeryQueue(FoodBox box) throws InterruptedException;

    /**
     * Simulates the sale of a box of food products, by retrieving an element
     * from the queue of packaged products. The requirement is that the
     * supermarket delivery queue is checked first, then the one for bakeries.
     * 
     * @throws InterruptedException due to our simulation via sleep()
     */
    public FoodBox poll() throws InterruptedException;
}
