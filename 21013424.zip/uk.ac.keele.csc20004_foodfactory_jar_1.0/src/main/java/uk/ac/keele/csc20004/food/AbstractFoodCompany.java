/* **********************
 * CSC-20004 COURSEWORK *
 * 2022/23 Resit        *
 * **********************/
package uk.ac.keele.csc20004.food;

import uk.ac.keele.csc20004.food.ingredients.Bun;
import uk.ac.keele.csc20004.food.ingredients.BunStorage;
import uk.ac.keele.csc20004.food.ingredients.Eggs;
import uk.ac.keele.csc20004.food.ingredients.EggsStorage;
import uk.ac.keele.csc20004.food.ingredients.FoodStorage;
import uk.ac.keele.csc20004.food.ingredients.Sausage;
import uk.ac.keele.csc20004.food.ingredients.SausageStorage;
import uk.ac.keele.csc20004.food.ingredients.VegetableStorage;
import uk.ac.keele.csc20004.food.ingredients.Vegetables;

/**
 * A partial implementation of a food company.
 * This class does not contain the implementation for the delivery queues,
 * which will need to be provided by concrete classes.
 */
public abstract class AbstractFoodCompany implements FoodCompany {
    protected FoodStorage<Eggs> eggsShelf;
    protected FoodStorage<Bun> bunShelf;
    protected FoodStorage<Sausage> sausageFridge;
    protected FoodStorage<Vegetables> veggieFridge;

    protected final int boxSize;

    public AbstractFoodCompany(int boxSize) {
        this.boxSize = boxSize;

        eggsShelf = new EggsStorage();
        bunShelf = new BunStorage();
        sausageFridge = new SausageStorage();
        veggieFridge = new VegetableStorage();
    }
    
    /**
     * @return the shelf holding eggs
     */
    public FoodStorage<Eggs> getEggsStorage() {
        return eggsShelf;
    }

    /**
     * @return the shelf holding buns
     */
    public FoodStorage<Bun> getBunStorage() {
        return bunShelf;
    }

    /**
     * @return the fridge holding sausages
     */
    public FoodStorage<Sausage> getSausageStorage() {
        return sausageFridge;
    }

    /**
     * @return the fridge holding vegetables
     */
    public FoodStorage<Vegetables> getVegetablesStorage() {
        return veggieFridge;
    }

}
