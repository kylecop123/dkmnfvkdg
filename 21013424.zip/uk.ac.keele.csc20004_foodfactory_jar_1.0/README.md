# CSC-20004 - Coursework (resit)

This is the starting code for the coursework of module CSC-20004 Advanced Programming practices - resit session August 2023

Please refer to the text of the coursework, available on KLE, for an explanation of the code and the instructions for submission. Make sure to check for the deadline on KLE.

The hierarchy of the provided classes for the ingredients is reported here:

![UML diagram 1](./hierarchy-ingredients.png)

The hierarchy relative to the Food products is reported here:

![UML diagram 2](./hierarchy-products.png)
